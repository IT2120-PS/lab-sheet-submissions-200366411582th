setwd("C:/Users/thvit/Desktop/IT24101688")
prob_train <- punif(25, min=0, max=40) - punif(10, min=0, max=40)
prob_train

# 2. 
lambda <- 1/3
prob_update <- pexp(2, rate=lambda)
prob_update

# 3. 
mu <- 100
sigma <- 15

# i. 
prob_IQ_above130 <- 1 - pnorm(130, mean=mu, sd=sigma)
prob_IQ_above130

# ii. IQ score for 95th percentile
IQ_95th <- qnorm(0.95, mean=mu, sd=sigma)
IQ_95th
