setwd("C:\\Users\\IT24101688\\Desktop\\IT24101688")

#1
branch_data <- read.csv(file.choose(), header = TRUE)
head(branch_data)

#2 
str(branch_data)

#3
boxplot(branch_data$Sales, main="Boxplot of Sales", col="skyblue")
fivenum(branch_data$Advertising)
IQR(branch_data$Advertising)

#4
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR <- Q3 - Q1
  lower <- Q1 - 1.5*IQR
  upper <- Q3 + 1.5*IQR
  return(x[x < lower | x > upper])
}

find_outliers(branch_data$Years)
